package com.techyourchance.mockitofundamentals.example7.eventbus;

public interface EventBusPoster {

    void postEvent(Object event);

}
