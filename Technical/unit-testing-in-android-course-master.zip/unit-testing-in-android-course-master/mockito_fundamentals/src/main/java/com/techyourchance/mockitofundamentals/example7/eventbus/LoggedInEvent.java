package com.techyourchance.mockitofundamentals.example7.eventbus;

public class LoggedInEvent {}
