package com.techyourchance.mockitofundamentals.example7.networking;

public class NetworkErrorException extends Exception {
}
