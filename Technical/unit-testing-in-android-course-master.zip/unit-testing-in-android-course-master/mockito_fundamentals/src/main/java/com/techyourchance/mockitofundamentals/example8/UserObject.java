package com.techyourchance.mockitofundamentals.example8;

import java.util.List;

public class UserObject {

    public void logOut() {
        // real implementation here
    }

    public void connectWith(UserObject otherUser) {
        // real implementation here
    }

    public List<UserObject> getConnectedUsers() {
        // real implementation here
        return null;
    }

    public void disconnectFromAll() {
        // real implementation here
    }

}
