package com.techyourchance.mockitofundamentals.exercise5.eventbus;

public interface EventBusPoster {

    void postEvent(Object event);

}
