package com.techyourchance.mockitofundamentals.exercise5.networking;

public class NetworkErrorException extends Exception {
}
