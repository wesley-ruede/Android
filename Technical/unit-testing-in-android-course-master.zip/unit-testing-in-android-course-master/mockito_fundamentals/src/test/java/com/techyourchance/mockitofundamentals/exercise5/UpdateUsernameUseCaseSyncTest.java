package com.techyourchance.mockitofundamentals.exercise5;

public class UpdateUsernameUseCaseSyncTest {

}