package com.techyourchance.testdoublesfundamentals.example4.eventbus;

public class LoggedInEvent {}
