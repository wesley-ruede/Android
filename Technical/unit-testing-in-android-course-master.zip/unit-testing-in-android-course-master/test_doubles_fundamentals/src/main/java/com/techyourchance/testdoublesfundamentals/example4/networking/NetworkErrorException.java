package com.techyourchance.testdoublesfundamentals.example4.networking;

public class NetworkErrorException extends Exception {
}
