package com.techyourchance.testdoublesfundamentals.exercise4;

public class FetchUserProfileUseCaseSyncTest {

}