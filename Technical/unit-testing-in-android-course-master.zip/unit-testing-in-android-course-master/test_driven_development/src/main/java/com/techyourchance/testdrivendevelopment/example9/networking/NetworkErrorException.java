package com.techyourchance.testdrivendevelopment.example9.networking;

public class NetworkErrorException extends Exception {
}
