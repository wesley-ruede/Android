package com.techyourchance.testdrivendevelopment.exercise6.networking;

public class NetworkErrorException extends Exception {
}
