package com.techyourchance.unittesting.common.time;

public class TimeProvider {

    public long getCurrentTimestamp() {
        return System.currentTimeMillis();
    }
}
