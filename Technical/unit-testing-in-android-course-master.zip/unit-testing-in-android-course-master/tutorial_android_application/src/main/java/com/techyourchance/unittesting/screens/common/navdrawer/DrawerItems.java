package com.techyourchance.unittesting.screens.common.navdrawer;

public enum DrawerItems {
    QUESTIONS_LIST
}
