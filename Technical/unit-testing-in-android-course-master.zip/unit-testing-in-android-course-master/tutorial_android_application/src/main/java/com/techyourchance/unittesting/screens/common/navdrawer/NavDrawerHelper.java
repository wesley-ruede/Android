package com.techyourchance.unittesting.screens.common.navdrawer;

public interface NavDrawerHelper {

    void openDrawer();
    void closeDrawer();
    boolean isDrawerOpen();
}
