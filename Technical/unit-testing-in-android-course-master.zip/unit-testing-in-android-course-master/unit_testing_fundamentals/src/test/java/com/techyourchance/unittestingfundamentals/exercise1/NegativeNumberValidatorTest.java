package com.techyourchance.unittestingfundamentals.exercise1;

public class NegativeNumberValidatorTest {

}