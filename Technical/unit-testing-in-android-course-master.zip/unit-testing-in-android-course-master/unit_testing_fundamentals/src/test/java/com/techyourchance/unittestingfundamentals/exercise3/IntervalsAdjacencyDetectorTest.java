package com.techyourchance.unittestingfundamentals.exercise3;

public class IntervalsAdjacencyDetectorTest {

}