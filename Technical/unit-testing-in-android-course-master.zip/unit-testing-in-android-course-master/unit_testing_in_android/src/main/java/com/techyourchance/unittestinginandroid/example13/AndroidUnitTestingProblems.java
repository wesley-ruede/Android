package com.techyourchance.unittestinginandroid.example13;

import android.text.TextUtils;

public class AndroidUnitTestingProblems {

    public void callStaticAndroidApi(String string) {
        TextUtils.isEmpty(string);
    }
}
